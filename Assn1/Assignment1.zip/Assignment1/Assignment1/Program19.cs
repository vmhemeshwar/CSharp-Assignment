﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program19
    {
        static void Main(string[] args)
        {
            Console.Write("Enter word: ");
            String s1 = Console.ReadLine();
            char[] arr = s1.ToCharArray();
            int i = 0, j = arr.Length - 1;
            bool flag = true;
            while (i < j)
            {
                if (arr[i].ToString().ToUpper() != arr[j].ToString().ToUpper())
                {
                    flag = false;
                }
                i++;
                j--;
            }

            if (flag)
            {
                Console.WriteLine("Palindrome");
            }
            else
            {
                Console.WriteLine("Not Palindrome");
            }


            Console.Read();
        }

    }
}
