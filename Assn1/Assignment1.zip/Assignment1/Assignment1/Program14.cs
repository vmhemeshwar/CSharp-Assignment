﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program14
    {
        /*
        static void Main(string[] args)
        {
            //Console.WriteLine("Welcome to the World of C#");
            int[] arr = new int[5];
            Console.WriteLine("Enter 5 No.s: ");
            for (int i = 0; i < 5; i++)
            {
                arr[i] = Int32.Parse(Console.ReadLine());
            }

            int min = arr[0];
            foreach (int n in arr)
            {
                if (n < min)
                {
                    min = n;
                }
            }
            Console.WriteLine("Min No. is " + min);
            Console.ReadKey();
        }*/
    }
}
