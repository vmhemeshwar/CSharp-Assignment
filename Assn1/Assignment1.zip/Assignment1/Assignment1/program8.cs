﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class program8
    {

        static void Main(string[] args)
        {
            Console.Write("Enter No.: ");
            int a = Int32.Parse(Console.ReadLine());
            int fact = 1;
            while (a > 0)
            {
                fact *= a;
                a--;
            }
            Console.WriteLine(fact);
            Console.ReadKey();
        }
    }
}
