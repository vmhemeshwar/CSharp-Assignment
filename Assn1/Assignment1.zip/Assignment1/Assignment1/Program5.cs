﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program5
    {
        static void Main()
        {
            int n;
            Console.Write("Enter No. of no.s: ");
            n = Int32.Parse(Console.ReadLine());
            int[] arr = new int[n];
            Console.WriteLine("Enter no.s");
            for(int i=0;i<n;i++)
            {
                arr[i] = Int32.Parse(Console.ReadLine());
            }
            int o = 0, e = 0;
            foreach(int i in arr)
            {
                if(i%2==0)
                {
                    e++;
                }
                else
                {
                    o++;
                }
            }
            Console.WriteLine("Odd No.s: " + o + " Even No.s: " + e);
            Console.Read();
        }
        
    }
}
