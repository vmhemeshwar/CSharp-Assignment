﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{

    class Program2
    {
        static void Main(String[] args)
        {
            Console.Write("Enter Username: ");
            String name = Console.ReadLine();
            Console.WriteLine("Welcome " + name + " to the world of C#");
            Console.ReadKey();
        }
    }
}
