﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program15
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];

            int ch;
            Console.WriteLine("enter 10 marks: ");
            for (int i = 0; i < 10; i++)
            {
                arr[i] = Int32.Parse(Console.ReadLine());
            }

            do
            {
                Console.WriteLine("------------------------ Menu ------------------------");
                Console.WriteLine("1. Display Total");
                Console.WriteLine("2. Display Average");
                Console.WriteLine("3. Display Max");
                Console.WriteLine("4. Display Min");
                Console.WriteLine("5. Display Marks in Ascending");
                Console.WriteLine("6. Display Marks in Descending");
                Console.WriteLine("0. Exit");
                Console.Write("Enter Choice: ");
                ch = Int32.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1: total(arr); break;
                    case 2: avg(arr); break;
                    case 3: max(arr); break;
                    case 4: min(arr); break;
                    case 5: sort(arr, 1); break;
                    case 6: sort(arr, 2); break;
                }

            } while (ch != 0);


            Console.ReadKey();
        }

        static void total(int[] a)
        {
            int t = 0;
            foreach (int n in a)
            {
                t += n;
            }
            Console.WriteLine("Total is " + t);
        }

        static void avg(int[] a)
        {
            float avg = 0.0f;
            float t = 0f;
            foreach (int n in a)
            {
                t += n;
            }
            avg = (t / a.Length);
            Console.WriteLine("Average is " + avg);
        }

        static void max(int[] a)
        {
            int max = a[0];
            foreach (int n in a)
            {
                if (n > max)
                {
                    max = n;
                }
            }
            Console.WriteLine("Max No. is " + max);
        }

        static void min(int[] a)
        {
            int min = a[0];
            foreach (int n in a)
            {
                if (n < min)
                {
                    min = n;
                }
            }
            Console.WriteLine("Min No. is " + min);
        }

        static void sort(int[] a, int o)
        {

            Array.Sort(a);

            if (o == 2)
            {
                Array.Reverse(a);
            }

            foreach (int n in a)
            {
                Console.Write(" " + n);
            }
            Console.WriteLine();
        }
    }
}
