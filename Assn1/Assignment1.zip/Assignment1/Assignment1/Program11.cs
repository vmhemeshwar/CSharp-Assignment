﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program11
    {

        static void Main(string[] args)
        {
            Console.Write("Enter No.: ");
            int a = Int32.Parse(Console.ReadLine());
            for (int i = 1; i <= 20; i++)
            {
                Console.WriteLine(a + " x " + i + " = " + (a * i));
            }
            Console.ReadKey();
        }
    }
}
