﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program16
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a word: ");
            String s = Console.ReadLine();
            Console.WriteLine("Length is " + s.Length);
            Console.Read();
        }
    }
}
