﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program3
    {
        static void Main(string[] args)
        {
            for (int i = Int32.Parse(args[0]) + 1; i < Int32.Parse(args[1]); i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
