﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program6
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the World of C#");
            Console.Write("Enter temp in F: ");
            float ftemp = float.Parse(Console.ReadLine());
            float ctemp = ((ftemp - 32.0f) / 1.8f);
            Console.WriteLine(ctemp);
            Console.ReadKey();
        }
    }
}
