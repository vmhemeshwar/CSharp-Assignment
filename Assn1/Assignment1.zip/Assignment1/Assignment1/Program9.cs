﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program9
    {
        static void Main(string[] args)
        {
            int a = 0, b = 1;
            int temp = 0;
            while (temp < 40)
            {
                temp = a + b;
                a = b;
                b = temp;
                Console.WriteLine(b);
            }

            Console.ReadKey();
        }
    }
}
