﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program12
    {
        static void Main(string[] args)
        {
            int start = 200, end = 300;
            int fn = start + (7 - (start % 7));    // Calculating First No after 200 divisible by 7
            while (fn < end)
            {
                Console.WriteLine(fn);
                fn += 7;
            }


            Console.ReadKey();
        }
    }
}
