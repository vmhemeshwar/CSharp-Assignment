﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program10
    {

        static void Main(string[] args)
        {
            int sum = 0;
            Console.Write("Enter No.:");
            int n = Int32.Parse(Console.ReadLine());
            if (n > 5)
            {
                for (int i = 5; i <= n; i++)
                {
                    sum += (i * i * i);
                }
            }
            else if (n < 5 && n >= 0)
            {
                for (int i = n; i <= 5; i++)
                {
                    sum += (i * i * i);
                }
            }
            else if (n == 5)
            {
                sum = (5 * 5 * 5);
            }
            else
            {
                Console.WriteLine("Enter Valid No.");
            }

            Console.WriteLine("Sum is " + sum);

            Console.ReadKey();
        }

    }
}
