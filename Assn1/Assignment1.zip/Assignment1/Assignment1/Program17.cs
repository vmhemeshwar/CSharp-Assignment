﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program17
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a word: ");
            String s = Console.ReadLine();
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            s = new String(arr);
            Console.WriteLine(s);
            Console.Read();
        }
    }
}
