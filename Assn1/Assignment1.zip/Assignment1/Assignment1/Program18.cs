﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program18
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Welcome to the World of C#");
            Console.Write("Enter 2 words: ");
            String s1 = Console.ReadLine();
            String s2 = Console.ReadLine();
            if (s1.Equals(s2))
            {
                Console.WriteLine("Equal");
            }
            else
            {
                Console.WriteLine("Not equal");
            }
            Console.Read();
        }
    }
}
