﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program13
    {

        static void Main(string[] args)
        {
            int[] arr = new int[3];
            Console.WriteLine("Enter 3 No.s: ");
            for (int i = 0; i < 3; i++)
            {
                arr[i] = Int32.Parse(Console.ReadLine());
            }

            int max = arr[0];
            foreach (int n in arr)
            {
                if (n > max)
                {
                    max = n;
                }
            }
            Console.WriteLine("Max No. is " + max);
            Console.ReadKey();
        }
    }
}
