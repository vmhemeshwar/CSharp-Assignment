﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program7
    {

        static void Main(string[] args)
        {
            int i = 0;
            int off = 1;
            while (i <= 625)
            {
                Console.WriteLine(i);
                i = i + off;
                off += 2;
            }
            Console.ReadKey();
        }
    }
}
