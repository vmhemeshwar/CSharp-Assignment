﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the World of C#");
            
        }
        
    }
}
