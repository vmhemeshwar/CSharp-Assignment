﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Student1
    {
        string name;
        long rollNo;
        int clss;
        int sem;
        string branch;
        int[] marks= new int[5];

        public Student1()
        { }
        
        public Student1(string n, long r, int c,int s, string b, int[] arr)
        {
            name = n;
            rollNo = r;
            clss = c;
            sem = s;
            branch = b;

            for(int i=0;i<arr.Length;i++)
            {
                marks[i] = arr[i];
            }
        }
        
        public void displayResult()
        {
            int t = 0;
            bool flag = true;
            foreach(int m in marks)
            {
                t += m;
                if(m<35)
                {
                    flag = false;
                }
            }
            float avg = (float)t / marks.Length;
            if(avg<50)
            {
                flag = false;
            }

            if(flag)
            {
                Console.WriteLine("Result: Passed");
            }
            else
            {
                Console.WriteLine("Result: Failed");
            }
        }

        public void displayDetails()
        {
            Console.WriteLine("\nName: " + name + "\nRoll No.: " + rollNo + "\nClass: " + clss + "\nSemester: " + sem + "\nBranch: " + branch);
            Console.WriteLine("\n Marks:-");
            foreach(int m in marks)
            {
                Console.WriteLine("\t" + m);
            }
            displayResult();
        }
    
    }
}
