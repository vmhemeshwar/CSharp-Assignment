﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Program3_Driver
    {
        static void Main()
        {
            int ch=new int();
            Student1 s1 = new Student1();
            do
            {
                Console.WriteLine("-------------------------- Menu --------------------------");
                Console.WriteLine("1. Enter Student Details ");
                Console.WriteLine("2. Display Result ");
                Console.WriteLine("3. Display All Details");
                Console.WriteLine("0. Exit");
                Console.Write("Enter Choice: ");
                ch = Int32.Parse(Console.ReadLine());

                switch(ch)
                {
                    case 1: newStudent(ref s1);break;
                    case 2:s1.displayResult();break;
                    case 3: s1.displayDetails();break;                    
                }
            } while (ch!=0);

        }

        static void newStudent(ref Student1 s)
        {
            try
            {
                Console.Write("Enter Name: ");
                String n = Console.ReadLine();
                if(n.Equals(""))
                {
                    throw new Exception("Cannot be Blank");
                }

                Console.Write("Enter RollNo: ");
                long r = long.Parse(Console.ReadLine());
                if(r<0)
                {
                    throw new Exception("Negative not allowed");
                }

                Console.Write("Enter Class: ");
                int c = Int32.Parse(Console.ReadLine());
                if(c.Equals(""))
                {
                    throw new Exception("Cannot be Blank");
                }

                Console.Write("Enter Semester: ");
                int sem = Int32.Parse(Console.ReadLine());
                if(sem<0)
                {
                    throw new Exception("Negative not allowed");
                }

                Console.Write("Enter Branch: ");
                string b = Console.ReadLine();
                if(b.Equals(""))
                {
                    throw new Exception("Cannot be Blank");
                }

                int[] mrk = new int[5];
                for(int i=0;i<5;i++)
                {
                    Console.Write("Enter Mark " + (i+1)+": ");
                    mrk[i] = Int32.Parse(Console.ReadLine());
                    if(mrk[i]>100||mrk[i]<0)
                    {
                        throw new Exception("Enter Valid Mark");
                    }
                }

                s = new Student1(n, r, c, sem, b, mrk);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }
    }
}
