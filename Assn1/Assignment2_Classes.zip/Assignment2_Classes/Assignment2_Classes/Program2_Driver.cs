﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Program2_Driver
    {
        static void Main(string[] args)
        {
            Accounts a1 = new Accounts();
            int ch;
            do
            {
                Console.WriteLine("-------------------------- Menu --------------------------");
                Console.WriteLine("1. Enter Account Details ");
                Console.WriteLine("2. New Transaction ");
                Console.WriteLine("3. Check Balance");
                Console.WriteLine("0. Exit");
                Console.Write("Enter Choice: ");
                ch = Int32.Parse(Console.ReadLine());
                switch(ch)
                {
                    case 1: a1.accept();break;
                    case 2: a1.transact(); break;
                    case 3: Console.WriteLine("Balance is : " + a1.BALANCE);break;
                    case 0: Console.WriteLine("Exiting....");break;
                    default: Console.WriteLine("Enter Valid No.: ");break;
                }
            } while (ch!=0);            
            Console.Read();
        }
    }
}
