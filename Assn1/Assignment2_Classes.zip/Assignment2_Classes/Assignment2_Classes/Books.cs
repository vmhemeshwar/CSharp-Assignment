﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Books
    {
        string name;
        int isbn;
        string author;
        int qty;
        float price;

        public Books()
        {}

        public Books(string n,int i,string a,int q,float p)
        {
            name = n;
            isbn = i;
            author = a;
            qty = q;
            price = p;
        }

        public float getPrice(int q)
        {
            float tp=0f
;
            try
            {
                if (q > qty)
                {                    
                    throw new Exception("Quantity Exceeded");
                    
                }
                tp = price * q;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return tp;
        }

        public void dispDetails()
        {
            Console.WriteLine(isbn + "\t\t" + name + "\t\t" + author + "\t\t" + qty + "\t\t" + price+"\n");
        }
        
        public void alterQty(int i)
        {
            int temp = (qty - i);
            if(temp>0)
            {
                qty -= i;
            }
            
        }
    }
}
