﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Program5_Driver
    {
       
        static void Main()
        {
            int ch = new int();
            int globalIndex = 0;
            List<Books> bookList = new List<Books>();
            do
            {
                Console.WriteLine("-------------------------- Menu --------------------------");
                Console.WriteLine("1. Add Books to Inventory ");
                Console.WriteLine("2. New Order ");
                Console.WriteLine("3. Check Inventory");
                Console.WriteLine("0. Exit");
                Console.Write("Enter Choice: ");
                ch = Int32.Parse(Console.ReadLine());

                switch(ch)
                {
                    case 1:addBooks(ref bookList, ref globalIndex);break;
                    case 2:newOrder(ref bookList);break;
                    case 3:checkInventory(bookList);break;
                }

            } while (ch!=0);
            Console.Write("Enter No. of books to be stored");
        }

        static void addBooks(ref List<Books> l,ref int gi)
        {
            try
            {
                Console.Write("Enter No. of books to be added: ");
                int n = Int32.Parse(Console.ReadLine());
                if(n<0)
                {
                    throw new Exception("Cannot be Negative");
                }
                while(n>0)
                {
                    Console.Write("Enter Book Name: ");
                    string nm = Console.ReadLine();
                    if(nm.Equals(""))
                    {
                        throw new Exception("Cannot be Blank");
                    }

                    Console.Write("Enter Book ISBN: ");
                    int ibn = Int32.Parse(Console.ReadLine());
                    if(ibn<0)
                    {
                        throw new Exception("Cannot be negative");
                    }

                    Console.Write("Enter Book Author: ");
                    string a = Console.ReadLine();
                    if(a.Equals(""))
                    {
                        throw new Exception("Cannot be blank");
                    }

                    Console.Write("Enter Book Quantity: ");
                    int q = Int32.Parse(Console.ReadLine());
                    if(q<0)
                    {
                        throw new Exception("Cannot be negative");
                    }

                    Console.Write("Enter Book Price: ");
                    float p = float.Parse(Console.ReadLine());
                    if(p<0)
                    {
                        throw new Exception("Cannot be Negative");
                    }

                    Books b1 = new Books(nm, ibn, a, q, p);
                    l.Add(b1);
                    n--;
                    gi++;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

            }
        }

        static void newOrder(ref List<Books> l)
        {
            char cont = new char();
            float tp = 0;
            List<int> orderlist = new List<int>();
            do
            {
                a:
                Console.WriteLine("S.No\tISBN\t\tName\t\tAuthor\t\tQuantity\t\tPrice\n--------------------------------------------------------------------------------------------------------");
                int j = 1;
                foreach (Books b in l)
                {
                    Console.Write("\n"+j+"\t");
                    b.dispDetails();
                    j++;
                }
                Console.Write("Enter S.No of book to purchase: ");
                int sno = Int32.Parse(Console.ReadLine());
                if(sno>l.ToArray().Length)
                {
                    Console.WriteLine("Not Valid S.No.");
                    goto a;
                }
                Console.Write("Enter Qty of the book: ");
                int q = Int32.Parse(Console.ReadLine());
                tp += l.ElementAt(sno - 1).getPrice(q);
                l.ElementAt(sno - 1).alterQty(q);
                Console.WriteLine("Proceed to Cart(y) or buy more books(n) ?: ");
                cont = char.Parse(Console.ReadLine());

            } while (cont!='y');
            

            Console.WriteLine("Total Price for Order is: Rs." + tp);
            
        }

        static void checkInventory(List<Books> l)
        {
            Console.WriteLine("S.No\tISBN\t\tName\t\tAuthor\t\tQuantity\t\tPrice\n--------------------------------------------------------------------------------------------------------");

            int j = 1;
            foreach (Books b in l)
            {
                Console.Write("\n" + j + "\t");
                b.dispDetails();
                j++;
            }

        }
    }
}
