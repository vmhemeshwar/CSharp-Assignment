﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Program6_Driver
    {
        static void Main(string[] args)
        {
            Shapes s = new Shapes();
            int ch;
            try
            {
                do
                {
                    Console.WriteLine("-------------------------- Menu --------------------------");
                    Console.WriteLine("1. Square ");
                    Console.WriteLine("2. Circle ");
                    Console.WriteLine("3. triangle");
                    Console.WriteLine("4. Rectangle");
                    Console.WriteLine("0. Exit" +
                        "");
                    Console.Write("Enter Choice: ");
                    ch = Int32.Parse(Console.ReadLine());

                    switch(ch)
                    {
                        case 1: shape1side(1);break;
                        case 2: shape1side(2);break;
                        case 3: shape2side(2);break;
                        case 4: shape2side(1);break;
                        case 0: Console.WriteLine("Exiting...");break;
                        default:Console.WriteLine("Enter Valid Choice");break;
                    }


                } while (ch!=0);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.Read();
        }

        static void shape1side(int i)
        {
            Shapes s1 = new Shapes();
            try
            {
                if (i == 1)
                {

                    Console.Write("Enter Square Side Length: ");
                    float side = float.Parse(Console.ReadLine());
                    if (side < 0)
                    {
                        throw new Exception("Negative not allowed");
                    }
                    Console.WriteLine("Area of Square is " + s1.area(side));
                }
                else
                {
                    Console.Write("Enter Circle Radius: ");
                    double rad = double.Parse(Console.ReadLine());
                    if(rad<0)
                    {
                        throw new Exception("Negative not allowed");
                    }
                    Console.WriteLine("Area of Circle is " + s1.area(rad));

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);                
            }
            
        }

        static  void shape2side(int i)
        {
            Shapes s1 = new Shapes();
            try
            {
                if (i == 1)
                {
                    Console.Write("Enter rectangle sides a and b");
                    float a = float.Parse(Console.ReadLine());
                    float b = float.Parse(Console.ReadLine());
                    if(a<0||b<0)
                    {
                        throw new Exception("Negative not allowed");
                    }
                    Console.WriteLine("Area of rectangle is " + s1.area(a, b));
                }
                else
                {
                    Console.Write("Enter triangle base and height ");
                    double b = double.Parse(Console.ReadLine());
                    double h = double.Parse(Console.ReadLine());
                    if(b<0||h<0)
                    {
                        throw new Exception("Negative not allowed");
                    }
                    Console.WriteLine("Area of Triangle is " + s1.area(b, h));
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
           
        }
    }
}
