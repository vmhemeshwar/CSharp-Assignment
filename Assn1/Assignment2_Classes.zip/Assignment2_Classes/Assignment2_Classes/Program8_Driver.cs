﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Program8_Driver
    {
        static void Main(string[] args)
        {
            Student2 s= new Student2();
            int ch;
            do
            {
                Console.WriteLine("-------------------------- Menu --------------------------");
                Console.WriteLine("1. Enter Student Details ");
                Console.WriteLine("2. View Total ");
                Console.WriteLine("3. View Percentage ");
                Console.WriteLine("0. Exit");
                Console.Write("Enter Choice: ");
                ch = Int32.Parse(Console.ReadLine());

                switch(ch)
                {
                    case 1: newStudent(ref s);break;
                    case 2: Console.WriteLine("Total is " + s.Total());break;
                    case 3: Console.WriteLine("Percentage is " + s.percentage()+"%");break;
                    case 0: Console.WriteLine("Exiting... ");break;
                    default: Console.WriteLine("Enter Valid Choice"); break;
                }

            } while (ch!=0);
            




        }

        static void newStudent(ref Student2 s)
        {
            try
            {
                Console.Write("Enter Name:");
                String name = Console.ReadLine();
                if(name.Equals(""))
                {
                    throw new Exception("Name Blank");
                }

                Console.Write("Enter Roll No:");
                long rno = long.Parse(Console.ReadLine());
                if(rno<0)
                {
                    throw new Exception("RollNo cannot be negative");
                }
                Console.Write("Enter English Marks:");
                float me = float.Parse(Console.ReadLine());
                if(me<0||me>100)
                {
                    throw new Exception("Enter Valid Marks");
                }

                Console.Write("Enter Maths Marks:");
                float mm = float.Parse(Console.ReadLine());
                if(mm<0||mm>100)
                {
                    throw new Exception("Enter Valid Marks");
                }
                

                Console.Write("Enter Science Marks:");
                float ms = float.Parse(Console.ReadLine());
                if(ms<0||ms>100)
                {
                    throw new Exception("Enter Valid Marks");
                }

                s = new Student2(name, rno, me, ms, mm);
            }
            catch (Exception e)
            {
                Console.Write(e.Message);
            }
                       
            
        }

        
    }
}
