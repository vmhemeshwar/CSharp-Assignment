﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Accounts
    {
        private long accountNo;
        private string custName;
        private string accType;
        private char transType;
        private float amount;
        private float balance;

        public long ACCOUNTNO
        {
            get { return accountNo; }
            set { accountNo = value; }
                
        }
        public string CUSTNAME
        {
            get { return custName; }
            set { custName = value; }

        }
        public string ACCTYPE
        {
            get { return accType; }
            set { accType = value; }

        }
        public char TRANSTYPE
        {
            get { return transType; }
            set { transType = value; }

        }
        public float AMOUNT
        {
            get { return amount; }
            set { amount = value; }

        }
        public float BALANCE
        {
            get { return balance; }
            set { balance = value; }

        }

        public void accept()
        {

            try
            {
                Console.Write("Enter Customer Name: ");
                custName = Console.ReadLine();
                if(custName.Equals(""))
                {
                    throw new Exception("Name Should not be blank");
                }
                Console.Write("Enter Account No.: ");
                accountNo = long.Parse(Console.ReadLine());
                if(accountNo<0)
                {
                    throw new Exception("Account No. Cannot be Negative");
                }
                Console.Write("Enter Balance: ");
                balance = float.Parse(Console.ReadLine());
                if(balance<0)
                {
                    throw new Exception("Balance Cannot be Negative");
                }
                Console.Write("Enter Account Type");
                accType = Console.ReadLine();

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
                
        }

        public void credit(float amt)
        {
            try
            {
                if(amt<0)
                {
                    throw new Exception("Amount Cannot be Negative");
                }
                balance += amt;
                Console.WriteLine("Amount Deposited ");

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }

        public void debit(float amt)
        {
            try
            {
                if(amt<0)
                {
                    throw new Exception("Amt Cannot be Negative");
                }
                balance -= amt;
                Console.WriteLine("Amount Withdrawn");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }

        public void transact()
        {
            try
            {
                Console.Write("Enter transaction type(d/w): ");
                transType = char.Parse(Console.ReadLine());
                if (transType == 'd')
                {
                    Console.Write("\nEnter amount to Deposit: ");
                    float amt = float.Parse(Console.ReadLine());
                    credit(amt);
                }
                else if (transType=='w')
                {
                    Console.Write("\nEnter amount to Withdraw: ");
                    float amt = float.Parse(Console.ReadLine());
                    if (amt > balance)
                    {
                        throw new Exception("Insufficient Funds");
                    }
                    debit(amt);
                }
                else
                {
                    throw new Exception("Enter Valid Transaction Type");
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);   
            }
            
        }
    }
}
