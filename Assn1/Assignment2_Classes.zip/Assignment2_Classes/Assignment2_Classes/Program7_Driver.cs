﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Program7_Driver
    {
        static void Main(string[] args)
        {
            Accounts2 a1 = new Accounts2();
            int ch;
            do
            {
                Console.WriteLine("-------------------------- Menu --------------------------");
                Console.WriteLine("1. Enter Account Details ");
                Console.WriteLine("2. Deposit ");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Check Balance");
                Console.WriteLine("0. Exit");
                Console.Write("Enter Choice: ");
                ch = Int32.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1: a1.accept(); break;
                    case 2: a1.transact('d'); break;
                    case 3: a1.transact('w'); break;
                    case 4:Console.WriteLine("Name: " + a1.CUSTNAME + " Balance: " + a1.BALANCE);break;
                    case 0: Console.WriteLine("Exiting...."); break;
                    default: Console.WriteLine("Enter Valid No.: "); break;
                }
            } while (ch != 0);
            Console.Read();
        }
    }
}
