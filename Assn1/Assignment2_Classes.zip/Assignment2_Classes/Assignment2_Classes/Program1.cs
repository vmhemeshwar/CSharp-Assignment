﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Program1
    {
        static void Main(string[] args)
        {
            float bal=new float() , mp=new float();
            try
            {
                Console.Write("Enter Credit card balance: ");
                bal = float.Parse(Console.ReadLine());
                if (bal < 0)
                {
                    throw new ArithmeticException("Balance Cannot be Negative");
                }
                Console.Write("\nEnter Monthly Payment: ");
                mp = float.Parse(Console.ReadLine());               
                if(mp<0)
                {
                    throw new ArithmeticException("Payment Cannot be Negative");
                }
            }
            catch(ArithmeticException e)
            {
                Console.WriteLine(e.Message);
            }

            int i = 1;
            while (bal >= 0) 
            {
                bal = bal - mp;  //New Balance for next month                
                Console.WriteLine("Month "+i+ " Balance: "+ bal +" Total Payments: "+(mp*i));
                bal = bal + (bal * 0.015f);
                i++;
            } 
            Console.Read();
            
        }
    }
}
