﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Shapes
    {
        float side;
        float a, b;
        double radius;
        double bas,height;
        
        public float area(float s)
        {
            side = s;
            return (s * s);
        }

        public double area(double r)
        {
            radius = r;
            return (3.14 * r * r);
        }

        public float area(float x, float y)
        {
            a = x;b = y;
            return (x * y);
        }
        public double area(double b,double h)
        {
            bas = b; height = h;
            return (b * h * 0.5);
        }
    }
}
