﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2_Classes
{
    class Student2
    {
        string name;
        long rollNo;
        float marksInEnglish;
        float marksInScience;
        float marksInMaths;

        public Student2(string n,long r, float me, float ms, float mm)
        {
            name = n;
            rollNo = r;
            marksInEnglish = me;
            marksInScience = ms;
            marksInMaths = mm;
        }

        public Student2()
        { }

        public float Total()
        {
            float t = (marksInEnglish + marksInScience + marksInMaths);
            //Console.WriteLine("Total Mark is " + );
            return t;

        }
        public float percentage()
        {
            float a = (Total() / 300.0f) * 100.0f;
            return a;
        }
        
    }
}
